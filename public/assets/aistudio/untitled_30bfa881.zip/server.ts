import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json());

// Enable CORS for external embed widgets and Systeme.io webhooks
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, DELETE');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  if (req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }
  next();
});

// In-memory data stores for API synchronization
let storedLeads: any[] = [];
let storedBookings: any[] = [];
let storedPaymentProofs: any[] = [
  {
    id: 'proof-init-1',
    clientName: 'Tariq Al-Mansoor (Apex Logistics UAE)',
    clientEmail: 'tariq@apexuae.com',
    clientPhone: '+971501234567',
    amount: 1500,
    currency: 'USD',
    paymentMethod: 'gcc_bank',
    paymentMethodLabel: 'Emirates NBD UAE IBAN (Direct)',
    transactionReference: 'ENBD-FT-2026-98124',
    receiptNote: 'Growth Plan kickoff 50% deposit retainer',
    status: 'verified',
    submittedAt: new Date(Date.now() - 3600000 * 24 * 2).toISOString(),
    verifiedAt: new Date(Date.now() - 3600000 * 24 * 1.8).toISOString(),
    verifiedBy: 'Ghazi Wazir (CEO)',
  },
  {
    id: 'proof-init-2',
    clientName: 'Bilal Khan (Al-Fajar Traders PK)',
    clientEmail: 'bilal@alfajartraders.pk',
    clientPhone: '+923009876543',
    amount: 1200,
    currency: 'USD',
    paymentMethod: 'pakistani_bank',
    paymentMethodLabel: 'Meezan Bank Raast (0-Fee IBFT)',
    transactionReference: 'MEZN-RAAST-4491028',
    receiptNote: 'E-commerce Funnel kickoff payment via Raast',
    status: 'pending_verification',
    submittedAt: new Date(Date.now() - 3600000 * 4).toISOString(),
  },
];

// Initialize Gemini SDK with telemetry header
const geminiApiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;
if (geminiApiKey && geminiApiKey !== 'MY_GEMINI_API_KEY' && !geminiApiKey.startsWith('MY_')) {
  try {
    ai = new GoogleGenAI({
      apiKey: geminiApiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  } catch (err) {
    console.warn('Could not initialize GoogleGenAI client:', err);
    ai = null;
  }
}

// System prompt for Back for Brand AI Concierge
const SYSTEM_INSTRUCTION = `You are the executive AI Concierge for Back for Brand LLC, an independent technology and growth engineering firm based in Florida, USA, founded and led by Ghazi Wazir.
Back for Brand builds high-converting sales funnels, high-performance websites, 24/7 AI chatbots & agents, CRM pipelines & automation, SEO/GEO search optimization, and custom apps/SaaS.

Key Information:
- Client Case Study: Bab Al-Khaleej Business Consultant in Bahrain (independent company also led by Ghazi Wazir).
- Philosophy: "One connected system, not six separate tools" — no data silos, 24/7 instant replies, 100% client asset ownership.
- Core Plans: Launch (getting online), Growth (most popular, includes 24/7 AI chatbot, CRM, automated follow-ups), Scale (full autonomous AI business OS).
- Location: Florida, USA, serving clients globally including North America, Europe, and the GCC.
- Tone: Professional, authoritative, conversion-focused, friendly, concise, and helpful.
- Goal: Answer visitor questions, guide them to the right solution, qualify their requirements, and invite them to request a free growth plan or book a strategy session with Ghazi Wazir.

Lead Extraction:
If the user provides their name, email address, phone number, or business needs, acknowledge it warmly and confirm that Back for Brand will follow up.`;

// API: AI Chat Concierge endpoint
app.post('/api/chat', async (req, res) => {
  try {
    const { message, history } = req.body;
    if (!message) {
      return res.status(400).json({ error: 'Message is required' });
    }

    // Check for contact details in message
    const emailMatch = message.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/);
    const phoneMatch = message.match(/(?:\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}/);
    let leadCaptured: any = null;
    if (emailMatch || phoneMatch) {
      leadCaptured = {
        name: emailMatch ? emailMatch[0].split('@')[0] : 'Inbound Prospect',
        email: emailMatch ? emailMatch[0] : undefined,
        phone: phoneMatch ? phoneMatch[0] : undefined,
        need: 'AI Concierge Inquiry',
      };
      storedLeads.unshift({
        id: 'lead-' + Math.random().toString(36).slice(2, 9),
        ...leadCaptured,
        src: 'WhatsApp',
        stage: 'New',
        val: 1200,
        createdAt: new Date().toISOString(),
      });
    }

    if (ai) {
      try {
        // Build conversation context
        const chatContents: any[] = [];
        if (Array.isArray(history)) {
          for (const item of history.slice(-6)) {
            chatContents.push({
              role: item.role === 'user' ? 'user' : 'model',
              parts: [{ text: item.text }],
            });
          }
        }
        chatContents.push({
          role: 'user',
          parts: [{ text: message }],
        });

        const aiPromise = ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: chatContents,
          config: {
            systemInstruction: SYSTEM_INSTRUCTION,
            temperature: 0.7,
          },
        });

        const timeoutPromise = new Promise((_, reject) =>
          setTimeout(() => reject(new Error('AI_TIMEOUT')), 4500)
        );

        const response: any = await Promise.race([aiPromise, timeoutPromise]);
        const reply = response.text || 'Thank you for reaching out. How else can we support your digital growth?';
        return res.json({ reply, leadCaptured });
      } catch (err) {
        console.warn('Gemini generateContent in /api/chat timed out or failed, using intelligent fallback:', err);
      }
    }

    // Fallback response if GEMINI_API_KEY is not configured or times out
    const lower = message.toLowerCase();
    let fallbackReply = `Thank you for reaching out to Back for Brand. We engineer full-funnel systems that turn visitors into customers on autopilot.`;
    if (lower.includes('price') || lower.includes('cost') || lower.includes('plan')) {
      fallbackReply = `Our packages start with our Launch plan, our flagship Growth tier (including 24/7 AI chatbot, CRM and automation), and our custom Scale architecture. We provide transparent, fixed-scope proposals tailored to your specific revenue targets.`;
    } else if (lower.includes('funnel') || lower.includes('website')) {
      fallbackReply = `We design custom high-converting funnels: Lead Generation for services, High-AOV Checkout for e-commerce, and Instant Booking funnels for clinics & consultants.`;
    } else if (lower.includes('contact') || emailMatch || phoneMatch) {
      fallbackReply = `Thank you! Your information has been registered into our CRM pipeline. Founder Ghazi Wazir and our team will review your requirements and follow up shortly.`;
    }

    return res.json({ reply: fallbackReply, leadCaptured });
  } catch (error: any) {
    console.error('Error in /api/chat:', error);
    return res.status(500).json({
      reply: 'Our team is ready to analyze your funnel. Please share your email or submit the form below for your free growth blueprint.',
    });
  }
});

// API: Leads endpoints
app.get('/api/leads', (_req, res) => {
  res.json({ leads: storedLeads });
});

app.post('/api/leads', (req, res) => {
  const newLead = {
    ...req.body,
    id: req.body.id || 'lead-' + Math.random().toString(36).slice(2, 9),
    createdAt: req.body.createdAt || new Date().toISOString(),
  };
  storedLeads.unshift(newLead);
  res.status(201).json({ success: true, lead: newLead });
});

// API: Bookings endpoints
app.get('/api/bookings', (_req, res) => {
  res.json({ bookings: storedBookings });
});

app.post('/api/bookings', (req, res) => {
  const newBooking = {
    ...req.body,
    id: req.body.id || 'bk-' + Math.random().toString(36).slice(2, 9),
    createdAt: req.body.createdAt || new Date().toISOString(),
  };
  storedBookings.push(newBooking);
  res.status(201).json({ success: true, booking: newBooking });
});

// API: WhatsApp and Email logs
let storedWhatsApp: any[] = [];
let storedEmails: any[] = [];
let storedProjects: any[] = [];

app.get('/api/whatsapp', (_req, res) => {
  res.json({ messages: storedWhatsApp });
});

app.post('/api/whatsapp', (req, res) => {
  const newMsg = {
    ...req.body,
    id: req.body.id || 'wa-' + Math.random().toString(36).slice(2, 9),
    timestamp: new Date().toISOString(),
  };
  storedWhatsApp.push(newMsg);
  res.status(201).json({ success: true, message: newMsg });
});

app.get('/api/emails', (_req, res) => {
  res.json({ emails: storedEmails });
});

app.post('/api/emails', (req, res) => {
  const newEmail = {
    ...req.body,
    id: req.body.id || 'em-' + Math.random().toString(36).slice(2, 9),
    timestamp: new Date().toISOString(),
  };
  storedEmails.push(newEmail);
  res.status(201).json({ success: true, email: newEmail });
});

app.get('/api/projects', (_req, res) => {
  res.json({ projects: storedProjects });
});

app.post('/api/projects', (req, res) => {
  const newProj = {
    ...req.body,
    id: req.body.id || 'proj-' + Math.random().toString(36).slice(2, 9),
  };
  storedProjects.push(newProj);
  res.status(201).json({ success: true, project: newProj });
});

// API: Webhook integration endpoint (Google Sheets, Zapier, Webflow)
app.post('/api/webhook', (req, res) => {
  const { name, email, phone, source, need, message } = req.body;
  const lead = {
    id: 'lead-' + Math.random().toString(36).slice(2, 9),
    name: name || email || 'Webhook Lead',
    email: email || '',
    phone: phone || '',
    src: source || 'Direct/Other',
    stage: 'New',
    val: 800,
    need: need || 'Webhook Inbound',
    message: message || '',
    createdAt: new Date().toISOString(),
  };
  storedLeads.unshift(lead);
  res.json({ status: 'ok', received: lead });
});

// API: Dedicated Systeme.io Webhook Handler
app.post('/api/webhook/systeme', (req, res) => {
  try {
    const raw = req.body || {};
    const channelQuery = (req.query.channel as string) || (req.body.channel as string) || (req.body.source as string) || 'Systeme.io';

    // Parse various Systeme.io payload structures
    const contact = raw.contact || raw.data || raw;
    const name =
      contact.name ||
      [contact.first_name, contact.last_name].filter(Boolean).join(' ') ||
      contact.email?.split('@')[0] ||
      raw.name ||
      'Systeme Lead';
    const email = contact.email || raw.email || '';
    const phone = contact.phone || raw.phone || '';
    const isSale = raw.event === 'sale' || raw.event === 'order' || raw.type === 'order' || !!raw.amount;
    const amount = parseFloat(raw.amount || raw.price || '0') || (isSale ? 1200 : 800);

    const lead = {
      id: 'lead-' + Math.random().toString(36).slice(2, 9),
      name,
      email,
      phone,
      src: channelQuery,
      stage: isSale ? 'Won' : 'New',
      val: amount,
      need: raw.funnel_name ? `Systeme.io: ${raw.funnel_name}` : (raw.need || 'Systeme.io Funnel Inbound'),
      message: `Systeme.io webhook: ${raw.event || 'form_submitted'} on ${channelQuery}`,
      createdAt: new Date().toISOString(),
    };

    storedLeads.unshift(lead);
    console.log(`[Systeme.io Webhook] Received lead for channel "${channelQuery}": ${name} (${email})`);
    res.status(200).json({ success: true, status: 'received', channel: channelQuery, lead });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Webhook processing failed' });
  }
});

app.get('/api/webhook/systeme', (req, res) => {
  const channel = req.query.channel || 'Systeme.io Channel';
  res.json({ status: 'active', message: `Systeme.io webhook endpoint ready for channel: ${channel}` });
});

// API: Global Payment Methods & Banking Config
app.get('/api/payments/config', (_req, res) => {
  res.json({
    stripe: {
      enabled: true,
      publishableKey: 'pk_live_51Pxxxxxxxxxxxxxxxxxxxxxxxx',
      retainerPaymentUrl: 'https://buy.stripe.com/bfb-retainer-500',
      growthPlanPaymentUrl: 'https://buy.stripe.com/bfb-growth-1500',
    },
    paypal: {
      enabled: true,
      merchantEmail: 'payments@backforbrand.com',
      paypalMe: 'https://paypal.me/backforbrand',
    },
    gccBanks: [
      {
        country: 'UAE',
        bankName: 'Emirates NBD',
        accountTitle: 'Back for Brand LLC - FZ',
        iban: 'AE070260001020304050607',
        swiftBic: 'EBILAEADXXX',
        currency: 'AED',
        networks: ['CBUAE Direct', 'Wire'],
      },
      {
        country: 'Saudi Arabia',
        bankName: 'Al Rajhi Bank (مصرف الراجحي)',
        accountTitle: 'Back for Brand Corporate',
        iban: 'SA4480000123456789012345',
        swiftBic: 'RJHISARIXXX',
        currency: 'SAR',
        networks: ['Mada', 'Wire'],
      },
      {
        country: 'Bahrain',
        bankName: 'National Bank of Bahrain (NBB)',
        accountTitle: 'Back for Brand W.L.L',
        iban: 'BH29NBOB00001122334455',
        swiftBic: 'NBOBBHBMXXX',
        currency: 'BHD',
        networks: ['BenefitPay', 'Wire'],
      },
    ],
    pakistaniBanks: [
      {
        bankName: 'Meezan Bank Ltd (Islamic Banking)',
        accountTitle: 'Ghazi Wazir / Back for Brand',
        accountNumber: '01020304050607',
        iban: 'PK82MEZN0001020304050607',
        raastId: '923001234567',
        branchCode: '0102',
        currency: 'PKR',
        serviceType: 'Instant Raast (0 Fee) / IBFT',
      },
      {
        bankName: 'Bank Alfalah Islamic',
        accountTitle: 'Back for Brand Technologies',
        accountNumber: '550198273645',
        iban: 'PK36ALFH5501982736450001',
        raastId: '923007654321',
        currency: 'PKR',
        serviceType: 'Freelance Remittance (PRC / Form-R)',
      },
    ],
    internationalWire: [
      {
        provider: 'Wise Multi-Currency',
        accountTitle: 'Back for Brand LLC',
        accountNumber: '9876543210',
        routingNumberAba: '084108966',
        swiftBic: 'TRWUS33XXX',
        bankName: 'Community Federal Savings Bank',
        supportedCurrencies: ['USD', 'EUR', 'GBP'],
      },
    ],
    crypto: {
      enabled: true,
      usdtTrc20Address: 'TYrN8xQp9vZ2jL5w4m7k1s3h6b8f0a9c2e',
      network: 'Tron (TRC-20)',
    },
  });
});

// API: Get Payment Proofs & Receipts
app.get('/api/payments/proofs', (_req, res) => {
  res.json({ proofs: storedPaymentProofs });
});

// API: Submit Client Payment Proof / Slip
app.post('/api/payments/submit-proof', (req, res) => {
  try {
    const {
      clientName,
      clientEmail,
      clientPhone,
      amount,
      currency = 'USD',
      paymentMethod = 'gcc_bank',
      paymentMethodLabel = 'Bank Transfer',
      transactionReference,
      receiptNote,
    } = req.body;

    if (!clientName || !amount) {
      return res.status(400).json({ error: 'Client name and amount are required.' });
    }

    const proof = {
      id: 'prf-' + Math.random().toString(36).slice(2, 9),
      clientName,
      clientEmail: clientEmail || '',
      clientPhone: clientPhone || '',
      amount: Number(amount),
      currency: (currency || 'USD').toUpperCase(),
      paymentMethod,
      paymentMethodLabel,
      transactionReference: transactionReference || 'REF-' + Date.now(),
      receiptNote: receiptNote || '',
      status: 'pending_verification',
      submittedAt: new Date().toISOString(),
    };

    storedPaymentProofs.unshift(proof);

    // Auto-update lead in CRM if email or name matches
    const matchedLead = storedLeads.find(
      (l) => (clientEmail && l.email && l.email.toLowerCase() === clientEmail.toLowerCase()) ||
             (l.name && l.name.toLowerCase() === clientName.toLowerCase())
    );

    if (matchedLead) {
      matchedLead.stage = 'Booked';
      matchedLead.val = Number(amount) || matchedLead.val;
      console.log(`[Payment API] Matched existing lead: ${matchedLead.name}, updated stage to Booked.`);
    } else {
      storedLeads.unshift({
        id: 'lead-' + Math.random().toString(36).slice(2, 9),
        name: clientName,
        email: clientEmail || '',
        phone: clientPhone || '',
        src: 'Direct Payment Portal',
        stage: 'Booked',
        val: Number(amount) || 1200,
        need: `Client Payment Proof: ${paymentMethodLabel}`,
        message: `Submitted ${currency} ${amount} via ${paymentMethodLabel}. Ref: ${transactionReference}`,
        createdAt: new Date().toISOString(),
      });
    }

    console.log(`[Payment API] New payment proof recorded: ${clientName} - ${amount} ${currency} (${paymentMethodLabel})`);
    res.status(200).json({
      success: true,
      message: 'Payment proof submitted successfully and queued for verification.',
      proof,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Payment submission failed' });
  }
});

// API: Verify or Reject Payment Proof (Admin / CEO)
app.post('/api/payments/verify', (req, res) => {
  try {
    const { id, status } = req.body;
    const target = storedPaymentProofs.find((p) => p.id === id);
    if (!target) {
      return res.status(404).json({ error: 'Proof submission not found' });
    }

    target.status = status === 'verified' ? 'verified' : 'rejected';
    target.verifiedAt = new Date().toISOString();
    target.verifiedBy = 'Ghazi Wazir (CEO)';

    if (status === 'verified') {
      const matched = storedLeads.find(
        (l) => (target.clientEmail && l.email && l.email.toLowerCase() === target.clientEmail.toLowerCase()) ||
               (l.name && l.name.toLowerCase() === target.clientName.toLowerCase())
      );
      if (matched) {
        matched.stage = 'Won';
        matched.val = target.amount || matched.val;
      }
    }

    res.json({ success: true, proof: target });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Verification failed' });
  }
});

// API: Stripe Webhook Ingestion
app.post('/api/webhook/stripe', (req, res) => {
  try {
    const event = req.body || {};
    console.log('[Stripe Webhook] Event received:', event.type || 'simulated');

    if (event.type === 'checkout.session.completed' || event.type === 'payment_intent.succeeded') {
      const data = event.data?.object || {};
      const customerEmail = data.customer_details?.email || data.receipt_email || 'client@stripe.com';
      const customerName = data.customer_details?.name || 'Stripe Customer';
      const amountTotal = (data.amount_total || data.amount || 150000) / 100;
      const currency = (data.currency || 'usd').toUpperCase();

      storedPaymentProofs.unshift({
        id: 'prf-stripe-' + Date.now(),
        clientName: customerName,
        clientEmail: customerEmail,
        amount: amountTotal,
        currency,
        paymentMethod: 'stripe',
        paymentMethodLabel: 'Stripe Card / Apple Pay (Auto-Cleared)',
        transactionReference: data.id || 'cs_live_' + Math.random().toString(36).slice(2, 9),
        receiptNote: 'Instant automated Stripe settlement',
        status: 'verified',
        submittedAt: new Date().toISOString(),
        verifiedAt: new Date().toISOString(),
        verifiedBy: 'Stripe Webhook System',
      });

      // Update CRM lead
      const matched = storedLeads.find((l) => l.email && l.email.toLowerCase() === customerEmail.toLowerCase());
      if (matched) {
        matched.stage = 'Won';
        matched.val = amountTotal;
      }
    }

    res.status(200).json({ received: true });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Webhook failed' });
  }
});

// API: PayPal Webhook Ingestion
app.post('/api/webhook/paypal', (req, res) => {
  try {
    const event = req.body || {};
    console.log('[PayPal Webhook] Event received:', event.event_type || 'simulated');

    if (event.event_type === 'PAYMENT.CAPTURE.COMPLETED' || event.event_type === 'CHECKOUT.ORDER.APPROVED') {
      const resource = event.resource || {};
      const payerEmail = resource.payer?.email_address || 'client@paypal.com';
      const payerName = resource.payer?.name?.given_name ? `${resource.payer.name.given_name} ${resource.payer.name.surname || ''}`.trim() : 'PayPal Payer';
      const amountVal = parseFloat(resource.amount?.value || '1200');
      const currency = resource.amount?.currency_code || 'USD';

      storedPaymentProofs.unshift({
        id: 'prf-paypal-' + Date.now(),
        clientName: payerName,
        clientEmail: payerEmail,
        amount: amountVal,
        currency,
        paymentMethod: 'paypal',
        paymentMethodLabel: 'PayPal International Instant Capture',
        transactionReference: resource.id || 'PAYPAL-TX-' + Math.random().toString(36).slice(2, 9),
        receiptNote: 'Instant PayPal IPN / Webhook capture',
        status: 'verified',
        submittedAt: new Date().toISOString(),
        verifiedAt: new Date().toISOString(),
        verifiedBy: 'PayPal Webhook Engine',
      });
    }

    res.status(200).json({ received: true });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Webhook failed' });
  }
});

// System Prompt for Trilingual WhatsApp Services & Booking Manager
const WHATSAPP_AGENT_SYSTEM_PROMPT = `You are the executive WhatsApp Services & Booking Manager for Back for Brand LLC, a premier digital technology and growth engineering firm based in Florida, USA, led by founder Ghazi Wazir.

Your Responsibilities:
1. Converse natively in the client's language:
   - English (Professional, consultative, direct)
   - Arabic / العربية (ترحيب راقٍ، أسلوب احترافي موجه لأصحاب الأعمال والشركات)
   - Urdu / اردو / Roman Urdu (پیشہ ورانہ، شائستہ اور کاروباری انداز)
2. Act as a proactive Booking Manager & Lead Qualifier:
   - Identify their business type and revenue targets.
   - Qualify their need: Funnel/Landing page, AI Chatbot & WhatsApp automation, E-commerce, SEO/Ads, or Full AI Business OS.
   - Gauge budget tier ($500 - $1,500 for Launch, $1,500 - $3,500 for Growth, $3,500+ for Scale).
   - Proactively guide them to book a free 15-minute Strategy Session with founder Ghazi Wazir.
3. Keep replies concise, conversational, and formatted with clean line breaks suitable for WhatsApp.
4. Output format: Provide your natural conversational message to the client, followed at the very end by an extraction JSON block inside <QUALIFICATION>...</QUALIFICATION> tags:
<QUALIFICATION>
{
  "qualificationScore": 85,
  "businessType": "string",
  "serviceNeeded": "string",
  "budgetTier": "string",
  "bookingRequested": boolean,
  "suggestedSlot": "string",
  "extractedContact": {
    "name": "string",
    "phone": "string",
    "email": "string"
  }
}
</QUALIFICATION>`;

// API: Trilingual WhatsApp Booking Manager endpoint
app.post('/api/whatsapp-agent', async (req, res) => {
  try {
    const { message, language = 'en', history = [], clientPhone, clientName } = req.body;
    if (!message) {
      return res.status(400).json({ error: 'Message is required' });
    }

    let reply = '';
    let qualification: any = {
      qualificationScore: 70,
      businessType: 'General Business',
      serviceNeeded: 'Funnel & Growth System',
      budgetTier: '$1,500 - $3,500 (Growth Plan)',
      bookingRequested: false,
      suggestedSlot: 'Tomorrow 11:00 AM',
      extractedContact: {
        name: clientName || '',
        phone: clientPhone || '',
      },
    };

    let generatedWithAi = false;
    if (ai) {
      try {
        const contents: any[] = [];
        if (Array.isArray(history)) {
          for (const item of history.slice(-6)) {
            contents.push({
              role: item.role === 'user' ? 'user' : 'model',
              parts: [{ text: item.text }],
            });
          }
        }
        contents.push({
          role: 'user',
          parts: [{ text: `[Language: ${language}, ClientName: ${clientName || 'Prospect'}, ClientPhone: ${clientPhone || 'Unknown'}]\n${message}` }],
        });

        const aiPromise = ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents,
          config: {
            systemInstruction: WHATSAPP_AGENT_SYSTEM_PROMPT,
            temperature: 0.6,
          },
        });

        const timeoutPromise = new Promise((_, reject) =>
          setTimeout(() => reject(new Error('AI_TIMEOUT')), 4500)
        );

        const response: any = await Promise.race([aiPromise, timeoutPromise]);

        const rawText = response.text || '';
        const qualMatch = rawText.match(/<QUALIFICATION>([\s\S]*?)<\/QUALIFICATION>/);
        if (qualMatch) {
          try {
            qualification = JSON.parse(qualMatch[1].trim());
            reply = rawText.replace(/<QUALIFICATION>[\s\S]*?<\/QUALIFICATION>/, '').trim();
          } catch {
            reply = rawText.replace(/<QUALIFICATION>[\s\S]*?<\/QUALIFICATION>/, '').trim();
          }
        } else {
          reply = rawText.trim();
        }
        if (reply) generatedWithAi = true;
      } catch (err) {
        console.warn('Gemini API call failed, switching to trilingual fallback:', err);
      }
    }

    if (!generatedWithAi) {
      // High-level trilingual fallback logic
      const lower = message.toLowerCase();
      if (language === 'ar' || /[\u0600-\u06FF]/.test(message)) {
        reply = `أهلاً بك! أنا مدير الحجوزات والخدمات في Back for Brand LLC.\n\nيسعدنا مساعدتك في بناء أنظمة الـ Funnel والذكاء الاصطناعي لتطوير مبيعاتك.\n\nهل ترغب في حجز جلسة استراتيجية مجانية عبر Google Meet مع المؤسس غازي وزير غداً الساعة 11:00 صباحاً أو 3:00 مساءً؟`;
        qualification.serviceNeeded = 'نظام المبيعات والذكاء الاصطناعي';
        qualification.qualificationScore = 85;
        qualification.bookingRequested = lower.includes('حجز') || lower.includes('موعد') || lower.includes('جلسة');
      } else if (language === 'ur' || lower.includes('salam') || lower.includes('kya') || lower.includes('chahiye')) {
        reply = `وعلیکم السلام! میں Back for Brand کا واٹس ایپ بکنگ مینیجر ہوں۔\n\nہم آپ کے کاروبار کے لیے ہائی کنورٹنگ سیلز فنلز، AI چیٹ بوٹس اور مکمل آٹومیشن تیار کرتے ہیں۔\n\nکیا آپ بانی غازی وزیر کے ساتھ 15 منٹ کا فری اسٹریٹیجی سیشن شیڈول کرنا چاہتے ہیں؟ ہمارے پاس کل صبح 11 بجے یا شام 4 بجے کا وقت دستیاب ہے۔`;
        qualification.serviceNeeded = 'Sales Funnel & AI Chatbot';
        qualification.qualificationScore = 85;
        qualification.bookingRequested = lower.includes('book') || lower.includes('call') || lower.includes('session');
      } else {
        reply = `Hello! I'm your WhatsApp Booking Manager from Back for Brand LLC (Florida, USA).\n\nWe build high-converting funnels, AI chatbots, and automated CRM pipelines that convert visitors into paying clients 24/7.\n\nMay I ask what business you're running, and would you like to reserve a 15-minute Strategy Session with founder Ghazi Wazir tomorrow at 11:00 AM?`;
        qualification.serviceNeeded = 'Funnels & AI Automation';
        qualification.qualificationScore = 85;
        qualification.bookingRequested = lower.includes('book') || lower.includes('call') || lower.includes('tomorrow') || lower.includes('session');
      }
    }

    // Ensure extractedContact is an object
    qualification.extractedContact = qualification.extractedContact || {};

    // Check if phone or email extracted
    const emailMatch = message.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/);
    const phoneMatch = message.match(/(?:\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}/);
    if (emailMatch) qualification.extractedContact.email = emailMatch[0];
    if (phoneMatch) qualification.extractedContact.phone = phoneMatch[0];

    // Auto-record qualified lead into CRM
    if ((qualification.qualificationScore || 70) >= 75) {
      const leadName = qualification.extractedContact.name || clientName || 'WhatsApp Qualified Lead';
      storedLeads.unshift({
        id: 'lead-' + Math.random().toString(36).slice(2, 9),
        name: leadName,
        phone: qualification.extractedContact.phone || clientPhone || '',
        email: qualification.extractedContact.email || '',
        src: 'WhatsApp',
        stage: qualification.bookingRequested ? 'Booked' : 'Contacted',
        val: qualification.budgetTier?.includes('3,500') ? 3500 : 1500,
        need: qualification.serviceNeeded || 'WhatsApp Qualified Pipeline',
        message: `WhatsApp qualified: ${message}`,
        createdAt: new Date().toISOString(),
      });
    }

    // Auto-schedule booking if requested
    if (qualification.bookingRequested) {
      const tomorrow = new Date(Date.now() + 3600000 * 24).toISOString().split('T')[0];
      storedBookings.push({
        id: 'bk-' + Math.random().toString(36).slice(2, 9),
        name: qualification.extractedContact.name || clientName || 'WhatsApp Client',
        phone: qualification.extractedContact.phone || clientPhone || '',
        email: qualification.extractedContact.email || '',
        date: tomorrow,
        time: '11:00',
        service: qualification.serviceNeeded || 'Strategy Session',
        durationMinutes: 45,
        meetingLink: 'https://meet.google.com/bfb-whatsapp-booking',
        st: 'Confirmed',
        notes: `Auto-booked via WhatsApp Manager. Lead score: ${qualification.qualificationScore}%`,
        createdAt: new Date().toISOString(),
      });
    }

    return res.json({ reply, qualification });
  } catch (error) {
    console.error('Error in /api/whatsapp-agent:', error);
    return res.status(500).json({
      reply: 'Back for Brand Booking Manager is standing by. Please share your phone or preferred time slot.',
      qualification: { qualificationScore: 60, bookingRequested: false },
    });
  }
});

// Meta WhatsApp Cloud API Webhook Verification (GET)
app.get('/api/webhook/whatsapp', (req, res) => {
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];

  const VERIFY_TOKEN = process.env.WHATSAPP_VERIFY_TOKEN || 'bfb_whatsapp_secret';

  if (mode === 'subscribe' && token === VERIFY_TOKEN) {
    console.log('[WhatsApp Webhook] Verification successful');
    res.status(200).send(challenge);
  } else {
    res.sendStatus(403);
  }
});

// Meta WhatsApp Cloud API Webhook Ingestion (POST)
app.post('/api/webhook/whatsapp', async (req, res) => {
  try {
    const body = req.body;
    console.log('[WhatsApp Webhook] Incoming message payload:', JSON.stringify(body));

    if (body.object) {
      if (
        body.entry &&
        body.entry[0].changes &&
        body.entry[0].changes[0].value.messages &&
        body.entry[0].changes[0].value.messages[0]
      ) {
        const messageObj = body.entry[0].changes[0].value.messages[0];
        const fromPhone = messageObj.from;
        const textBody = messageObj.text ? messageObj.text.body : '';

        // Store to WhatsApp chat logs
        storedWhatsApp.push({
          id: 'wa-' + messageObj.id,
          phone: fromPhone,
          clientName: 'WhatsApp Contact +' + fromPhone,
          direction: 'inbound',
          text: textBody,
          status: 'delivered',
          timestamp: new Date().toISOString(),
        });
      }
      res.status(200).send('EVENT_RECEIVED');
    } else {
      res.sendStatus(404);
    }
  } catch (err) {
    console.error('Error in POST /api/webhook/whatsapp:', err);
    res.sendStatus(500);
  }
});

// Health check
app.get('/api/health', (_req, res) => {
  res.json({ status: 'healthy', timestamp: new Date().toISOString() });
});

// Start server with Vite middleware in development or static in production
async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Back for Brand OS] Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
