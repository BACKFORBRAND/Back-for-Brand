import React, { useState } from 'react';
import { useBusiness } from '../../context/BusinessContext.tsx';
import { Send, CheckCircle2, Mail, ArrowRight } from 'lucide-react';

export const ContactFormSection: React.FC = () => {
  const { addLead, setCurrentView } = useBusiness();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [service, setService] = useState('Funnel or landing page');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email) return;

    // Estimate deal value based on service category
    let estimatedVal = 800;
    if (service.includes('Full AI')) estimatedVal = 3500;
    else if (service.includes('App') || service.includes('SaaS')) estimatedVal = 4000;
    else if (service.includes('chatbot')) estimatedVal = 1200;
    else if (service.includes('e-commerce')) estimatedVal = 1800;

    addLead({
      name,
      email,
      phone,
      src: 'Direct/Other',
      stage: 'New',
      val: estimatedVal,
      need: service,
      message,
    });

    setSubmitted(true);
  };

  const handleOpenMailClient = () => {
    const subject = encodeURIComponent(`Free growth plan request: ${service}`);
    const body = encodeURIComponent(
      `Name: ${name}\nEmail: ${email}\nPhone: ${phone}\nNeed: ${service}\n\nGoals:\n${message}\n\nSent via Back for Brand website.`
    );
    window.location.href = `mailto:hello@backforbrand.com?subject=${subject}&body=${body}`;
  };

  return (
    <section id="start" className="py-20 bg-gradient-to-br from-[#070e24] via-[#0c183a] to-[#070e24] text-white border-t border-[#cca34c]/20 relative overflow-hidden">
      {/* Brand Ambient Glows */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-[#00c48c]/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-[#cca34c]/10 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-[1160px] w-[92%] mx-auto text-center relative z-10">
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#00c48c]/15 text-[#00c48c] border border-[#00c48c]/30 text-xs font-black uppercase tracking-wider mb-4">
          Free Strategy Consultation
        </div>
        <h2 className="text-3xl sm:text-4xl lg:text-[46px] font-black tracking-tight leading-tight max-w-[720px] mx-auto mb-4 text-white">
          Ready to turn visitors into <span className="text-[#cca34c]">high-ticket customers</span>?
        </h2>
        <p className="text-base sm:text-lg text-emerald-100/80 max-w-[560px] mx-auto mb-10">
          Tell us about your business goals and <strong className="text-white font-bold">Back for Brand</strong> will architect an autonomous executive growth engine for you.
        </p>

        <div className="max-w-[640px] mx-auto bg-[var(--bg)] text-[var(--ink)] rounded-3xl p-7 sm:p-10 shadow-2xl text-left border-2 border-[#cca34c]/30 transition-colors">
          {submitted ? (
            <div className="text-center py-8">
              <div className="w-16 h-16 rounded-full bg-[#00c48c]/15 text-[#00c48c] border border-[#00c48c]/30 flex items-center justify-center mx-auto mb-4">
                <CheckCircle2 className="w-9 h-9" />
              </div>
              <h3 className="text-2xl font-black text-[var(--ink)] mb-2">
                Thank You, {name}!
              </h3>
              <p className="text-sm sm:text-base text-[var(--mu)] mb-6 max-w-[440px] mx-auto">
                Your request has been captured and instantly registered into our live <b className="text-[#00c48c]">Back for Brand OS</b>!
              </p>

              <div className="flex flex-col sm:flex-row gap-3 justify-center mb-4">
                <button
                  onClick={handleOpenMailClient}
                  className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-[var(--soft)] border border-[#cca34c]/40 text-[#cca34c] font-bold text-sm hover:bg-[#cca34c]/10 transition-colors"
                >
                  <Mail className="w-4 h-4" />
                  <span>Open in Mail App</span>
                </button>
                <button
                  onClick={() => setCurrentView('machine')}
                  className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-[#070e24] text-[#00c48c] border border-[#00c48c]/40 font-bold text-sm hover:bg-[#0c183a] transition-colors shadow-md"
                >
                  <span>View in Business Machine OS →</span>
                </button>
              </div>

              <button
                onClick={() => {
                  setSubmitted(false);
                  setName('');
                  setEmail('');
                  setMessage('');
                }}
                className="text-xs text-[var(--mu)] underline hover:text-[#00c48c]"
              >
                Submit another request
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="flex flex-col gap-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-[var(--ink)] mb-1">
                    Your Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Alex Miller"
                    autoComplete="name"
                    className="w-full text-sm px-4 py-3 rounded-xl border-2 border-[var(--bd)] bg-[var(--bg)] text-[var(--ink)] focus:outline-none focus:border-[#00c48c] focus:ring-4 focus:ring-[#00c48c]/15 transition-all"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-[var(--ink)] mb-1">
                    Your Email *
                  </label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="alex@company.com"
                    autoComplete="email"
                    className="w-full text-sm px-4 py-3 rounded-xl border-2 border-[var(--bd)] bg-[var(--bg)] text-[var(--ink)] focus:outline-none focus:border-[#00c48c] focus:ring-4 focus:ring-[#00c48c]/15 transition-all"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-[var(--ink)] mb-1">
                    WhatsApp or Phone (Optional)
                  </label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+1 555 0192 or +92 300..."
                    className="w-full text-sm px-4 py-3 rounded-xl border-2 border-[var(--bd)] bg-[var(--bg)] text-[var(--ink)] focus:outline-none focus:border-[#00c48c] focus:ring-4 focus:ring-[#00c48c]/15 transition-all"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-[var(--ink)] mb-1">
                    What do you need?
                  </label>
                  <select
                    name="s"
                    value={service}
                    onChange={(e) => setService(e.target.value)}
                    className="w-full text-sm px-4 py-3 rounded-xl border-2 border-[var(--bd)] bg-[var(--bg)] text-[var(--ink)] focus:outline-none focus:border-[#00c48c] focus:ring-4 focus:ring-[#00c48c]/15 transition-all"
                  >
                    <option>Funnel or landing page</option>
                    <option>Website or e-commerce</option>
                    <option>AI WhatsApp closer &amp; chatbot</option>
                    <option>SEO &amp; ads</option>
                    <option>App or SaaS</option>
                    <option>Full Back for Brand OS</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-[var(--ink)] mb-1">
                  Tell us about your business &amp; revenue goals
                </label>
                <textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="What are you currently selling, who is your target customer, and what is your monthly goal?"
                  rows={3}
                  className="w-full text-sm px-4 py-3 rounded-xl border-2 border-[var(--bd)] bg-[var(--bg)] text-[var(--ink)] focus:outline-none focus:border-[#00c48c] focus:ring-4 focus:ring-[#00c48c]/15 transition-all resize-none"
                />
              </div>

              <button
                type="submit"
                className="w-full py-4 rounded-xl bg-gradient-to-r from-[#00c48c] via-[#05df9d] to-[#cca34c] hover:from-[#00b07d] hover:to-[#b8903c] text-white font-black text-base shadow-[0_5px_0_#00875e] hover:shadow-[0_2px_0_#00875e] hover:translate-y-[2px] transition-all flex items-center justify-center gap-2 mt-2"
              >
                <span>Send my free plan request</span>
                <Send className="w-4 h-4 text-white" />
              </button>

              <p className="text-[11px] text-[var(--mu)] text-center mt-1">
                Zero spam. You'll receive a detailed growth teardown and direct access to founder Ghazi Wazir.
              </p>
            </form>
          )}
        </div>
      </div>
    </section>
  );
};
